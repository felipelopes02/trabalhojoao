public class Art {
    public static void main(String[] args) {
        //Use print statements to create your own beautiful original ASCII art.
        //Use comments to describe what your image is depicting.
        System.out.println("        _____");
        System.out.println("      /       \\");
        System.out.println("     /    /\\   \\");
        System.out.println("    /    /  \\   \\");
        System.out.println("   /    /    \\   \\");
        System.out.println("  /    /      \\   \\");
        System.out.println(" /____/________\\   \\");
        System.out.println(" \\                  /");
        System.out.prinln("  \\   JavaScript   /");
        System.out.println("   \\              /");
        System.out.println("    \\____________/");
    } 
}
